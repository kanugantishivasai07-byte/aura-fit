# AuraFit – AI-Powered Personal Fitness Assistant

AuraFit is a local AI fitness assistant prototype for the Snapdragon AI Lab challenge.

## Features
- Local machine-learning workout-intensity recommendation
- BMI and activity inputs
- Personalized workout plan
- Daily steps, water and workout tracker
- No cloud API required
- Architecture suitable for future Snapdragon/Qualcomm AI acceleration

## Run locally

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

The app opens in your browser.

## Suggested GitHub structure

```text
AuraFit/
├── app.py
├── requirements.txt
└── README.md
```

## Snapdragon optimization roadmap
1. Keep inference local.
2. Export the trained model to an edge-friendly format such as ONNX.
3. Benchmark CPU vs Snapdragon AI acceleration.
4. Add optional camera-based exercise/posture detection.
5. Measure latency and power consumption on a Snapdragon-powered PC.

## Important
The included training data is synthetic and is intended only for a prototype/demo. Replace it with properly collected and validated data before making health or medical claims.
