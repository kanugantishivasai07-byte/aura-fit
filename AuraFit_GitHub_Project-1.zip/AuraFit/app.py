import streamlit as st
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

st.set_page_config(page_title="AuraFit", page_icon="💪", layout="wide")

# -----------------------------
# Local AI model
# -----------------------------
@st.cache_resource
def train_local_model():
    rng = np.random.default_rng(42)
    n = 1200

    age = rng.integers(16, 65, n)
    bmi = rng.uniform(17, 35, n)
    activity = rng.integers(1, 8, n)       # days/week
    sleep = rng.uniform(4, 9, n)           # hours/night
    stress = rng.integers(1, 11, n)
    goal = rng.integers(0, 3, n)           # 0 fitness, 1 weight loss, 2 muscle

    # Synthetic labels for a demo/local recommendation model.
    score = (
        0.30 * activity
        + 0.45 * sleep
        - 0.30 * stress
        - 0.05 * abs(bmi - 23)
        + 0.25 * goal
        + rng.normal(0, 0.8, n)
    )

    intensity = np.where(score < 2.0, "Light",
                 np.where(score < 4.0, "Moderate", "High"))

    X = np.column_stack([age, bmi, activity, sleep, stress, goal])
    model = RandomForestClassifier(
        n_estimators=120,
        max_depth=8,
        random_state=42
    )
    model.fit(X, intensity)
    return model

model = train_local_model()

def recommend_workout(goal, intensity):
    plans = {
        "Weight Loss": {
            "Light": ["20 min brisk walk", "10 min mobility", "2 × 10 bodyweight squats"],
            "Moderate": ["30 min brisk walk/jog", "3 × 12 squats", "3 × 10 lunges", "3 × 20 sec plank"],
            "High": ["35 min cardio", "4 × 12 squats", "3 × 12 lunges", "3 × 30 sec plank"]
        },
        "Muscle Gain": {
            "Light": ["3 × 8 wall/incline push-ups", "3 × 10 squats", "3 × 20 sec plank"],
            "Moderate": ["3 × 10 push-ups", "4 × 10 squats", "3 × 10 lunges", "3 × 30 sec plank"],
            "High": ["4 × 12 push-ups", "4 × 12 squats", "4 × 10 lunges", "4 × 40 sec plank"]
        },
        "General Fitness": {
            "Light": ["20 min walk", "10 min stretching", "2 × 10 squats"],
            "Moderate": ["25 min cardio", "3 × 12 squats", "3 × 10 push-ups", "3 × 30 sec plank"],
            "High": ["30 min cardio", "4 × 12 squats", "4 × 10 push-ups", "4 × 40 sec plank"]
        }
    }
    return plans[goal][intensity]

# -----------------------------
# UI
# -----------------------------
st.title("💪 AuraFit")
st.subheader("AI-Powered Personal Fitness Assistant")
st.caption("Local AI demo — recommendations are generated on the device without a cloud API.")

with st.sidebar:
    st.header("Your Profile")
    age = st.slider("Age", 16, 70, 20)
    height = st.number_input("Height (cm)", 120.0, 220.0, 170.0)
    weight = st.number_input("Weight (kg)", 35.0, 180.0, 65.0)
    activity = st.slider("Current activity (days/week)", 0, 7, 3)
    sleep = st.slider("Average sleep (hours)", 3.0, 10.0, 7.0, 0.5)
    stress = st.slider("Stress level", 1, 10, 4)
    goal = st.selectbox("Fitness goal", ["General Fitness", "Weight Loss", "Muscle Gain"])

bmi = weight / ((height / 100) ** 2)

goal_id = {"General Fitness": 0, "Weight Loss": 1, "Muscle Gain": 2}[goal]
features = np.array([[age, bmi, activity, sleep, stress, goal_id]])
intensity = model.predict(features)[0]

col1, col2, col3 = st.columns(3)
col1.metric("BMI", f"{bmi:.1f}")
col2.metric("AI Intensity", intensity)
col3.metric("Activity", f"{activity}/7 days")

st.divider()

st.header("🤖 AuraFit AI Recommendation")
st.write(f"Based on your profile, AuraFit suggests a **{intensity.lower()}-intensity** session.")

workout = recommend_workout(goal, intensity)
for item in workout:
    st.write("✅", item)

st.divider()

st.header("📊 Daily Tracker")
steps = st.number_input("Steps today", 0, 50000, 5000, step=500)
water = st.slider("Water (litres)", 0.0, 6.0, 2.0, 0.25)
minutes = st.number_input("Workout minutes", 0, 300, 20)

progress = min(
    (steps / 8000) * 0.4 +
    (water / 3) * 0.2 +
    (minutes / 45) * 0.4,
    1.0
)

st.progress(progress)
st.write(f"Daily activity progress: **{progress*100:.0f}%**")

if progress >= 0.8:
    st.success("Great progress today! Keep your routine consistent.")
elif progress >= 0.5:
    st.info("Good start. A little more activity can improve your daily score.")
else:
    st.warning("Try adding a short walk or mobility session.")

st.divider()

st.header("📱 Snapdragon / Edge AI Concept")
st.write(
    "AuraFit is structured as an on-device AI application. "
    "The recommendation model is small and runs locally, making the architecture "
    "suitable for optimization with Snapdragon AI acceleration such as Qualcomm AI Engine."
)

st.caption(
    "Demo only. Fitness recommendations are not medical advice. "
    "Stop exercising if you experience pain, dizziness, or other concerning symptoms."
)
